BootupConsole.WriteDynamic("Bootup finished. Hello, Alex\n", 50);
Sleep(750);
BootupConsole.Clear();
BootupConsole.CursorVisible = true;
Sleep(1000);